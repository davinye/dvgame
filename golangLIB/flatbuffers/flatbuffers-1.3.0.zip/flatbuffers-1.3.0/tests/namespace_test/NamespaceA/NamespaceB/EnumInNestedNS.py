# automatically generated, do not modify

# namespace: NamespaceB

class EnumInNestedNS(object):
    A = 0
    B = 1
    C = 2

