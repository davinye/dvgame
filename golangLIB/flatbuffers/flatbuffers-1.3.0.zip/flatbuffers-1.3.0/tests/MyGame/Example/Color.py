# automatically generated, do not modify

# namespace: Example

class Color(object):
    Red = 1
    Green = 2
    Blue = 8

